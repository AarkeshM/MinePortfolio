import school from "./school.png";
import college from "./college.png";
import letter from "./DSC_5892.png";

export { school, letter, college };
